# SOS Alerter (Kotlin/Android)

Bu proje, gönderdiğin ekran görüntülerindeki uygulamaya benzer bir SOS/acil durum uygulamasının
kendi kod tabanımızla yazılmış, sıfırdan bir versiyonudur. Birebir kopya değildir; aynı işlevsellik
ve benzer görünüm hedeflenmiştir.

## APK'yı GitHub Actions ile Almak (Bilgisayarsız Yol)

Sadece telefon kullanıyorsan bile şu adımlarla APK üretebilirsin:

1. **GitHub'da hesap aç** (yoksa) — github.com üzerinden telefon tarayıcısıyla da yapılabilir.
2. **Yeni bir repo oluştur** (örneğin "sos-app" adında, "Private" seçebilirsin).
3. Bu klasördeki (`SosApp`) tüm dosyaları o repoya yükle:
   - Telefonda en kolayı: GitHub'ın mobil uygulamasını indirip repoyu açtıktan sonra dosyaları
     tek tek "Add file > Upload files" ile yüklemek biraz zahmetli olabilir (çok dosya var).
   - **Daha kolay yol**: Bir bilgisayara kısa süreliğine erişimin olursa (kütüphane, iş yeri, arkadaş),
     `git clone` + dosyaları kopyala + `git push` ile 2 dakikada hallolur.
   - Ya da GitHub'ın web arayüzünde "Upload files" ekranına bu zip'in içeriğini klasör yapısını
     koruyarak sürükleyip bırakabilirsin (tarayıcı bunu destekliyor, tüm klasörü sürükleyebilirsin).
4. Dosyalar repoya yüklenince, GitHub otomatik olarak `.github/workflows/build.yml` dosyasını
   algılar ve **Actions** sekmesinde "APK Derle" adında bir işlem başlar (birkaç dakika sürer).
5. İşlem bitince (yeşil tik ✓), o işlemin sayfasına gir, en altta **Artifacts** bölümünde
   `sos-app-debug-apk` adlı dosyayı göreceksin — ona dokunup indir.
6. İndirdiğin `.zip` dosyasının içinde `app-debug.apk` var — telefonuna indirip kurabilirsin
   (Android "bilinmeyen kaynaklardan kurulum" iznini açmanı isteyebilir, bu normal, kendi
   yaptığın bir uygulama olduğu için güvenli).

Not: Bu APK bir "debug" (geliştirme) sürümüdür — imzasızdır ama kendi telefonunda kurup
test etmek için tamamen yeterlidir.

## Nasıl Açılır (Bilgisayarda, Android Studio ile)

1. Android Studio'yu aç (Hedgehog veya üzeri önerilir).
2. "Open" ile bu `SosApp` klasörünü seç.
3. Android Studio otomatik olarak Gradle wrapper JAR dosyasını indirip senkronize edecektir
   (internet bağlantısı gerekir). İlk senkronizasyon birkaç dakika sürebilir.
4. Bir emülatör veya gerçek cihaz bağlayıp Run (▶) tuşuna bas.

## Yapı

- `MainActivity` — Alt navigasyon (Bottom Navigation) ile 4 sekmeyi yönetir: SOS, Geçmiş, Ayarlar, Bilgi.
- `SosFragment` — Ana ekran: büyük SOS butonu, birincil kişi kartı, GPS durumu, hızlı erişim.
- `TimelineFragment` — Geçmiş SOS olaylarının listesi.
- `SettingsFragment` — Profil, tetikleyiciler, yanıt ayarları, otomatik arama, kişi yönetimi.
- `InfoFragment` — Statik "hakkında" sayfası.
- `PrefsHelper` / `SettingsHelper` / `HistoryHelper` — Verileri cihazda (SharedPreferences, JSON) saklar.

## Şu An Gerçek Çalışan Özellikler

- SOS butonuna dokununca: konum alınır, kayıtlı tüm kişilere SMS gönderilir, geçmişe kaydedilir.
- Kişi ekleme/silme (Ayarlar sekmesi).
- Özel SOS mesajı, ayarların kalıcı olarak saklanması.
- Geçmiş (Timeline) listesi.

## Henüz Gerçek Tetikleyici Olarak Bağlanmamış Ayarlar (arayüzde var, işlevsel değil)

- Güç tuşuna 3x basma / ses tuşu tetikleyicisi — Android'de bunu güvenilir şekilde yakalamak
  özel/kısıtlı izinler (Accessibility Service, Device Admin) gerektirir ve cihaza göre değişir.
  İstersen bir sonraki adımda bunu da ekleyebiliriz.
- Sesli aktivasyon ("Yardım Et" de) — sürekli mikrofon dinleme servisi gerektirir, pil tüketimini
  ciddi artırır; eklemeden önce onayını almak istedim.
- Siren sesi / kamera flaşı yanıp sönmesi, otomatik arama — arayüzde ayar olarak duruyor,
  gerçek eylemi henüz tetiklenmiyor. Kolayca eklenebilir, istersen devam edelim.

## Önemli Not

Bu, referans aldığın uygulamanın birebir kopyası değil; aynı kategori/işlevde kendi
kodumuzla yazılmış bir alternatiftir. Marka adı, logo veya özel kod satırları kopyalanmamıştır.
