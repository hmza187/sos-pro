package com.example.sosapp

data class AppSettings(
    val fullName: String = "",
    val customMessage: String = "",

    // Tetikleyiciler
    val triggerPowerButton: Boolean = true,
    val triggerLongPressSos: Boolean = false,
    val triggerVolumeButtons: Boolean = false,
    val triggerShake: Boolean = false,
    val triggerVoice: Boolean = false,

    // Acil durum yanıtı
    val loudMode: Boolean = true,
    val playSiren: Boolean = true,
    val flashTorch: Boolean = true,
    val trackingIntervalSeconds: Int = 60,

    // Otomatik arama
    val emergencyCallingEnabled: Boolean = false,
    val callDelaySeconds: Int = 10,
    val primaryCallContactPhone: String = ""
)
