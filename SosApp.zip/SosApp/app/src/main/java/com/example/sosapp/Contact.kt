package com.example.sosapp

data class Contact(
    val name: String,
    val phone: String,
    val priority: Int = 1
)
