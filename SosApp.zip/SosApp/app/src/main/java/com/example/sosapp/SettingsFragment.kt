package com.example.sosapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SettingsFragment : Fragment() {

    private lateinit var contactsAdapter: ContactsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val settings = SettingsHelper.getSettings(requireContext())

        val fullNameInput = view.findViewById<EditText>(R.id.fullNameInput)
        val customMessageInput = view.findViewById<EditText>(R.id.customMessageInput)
        val switchPowerButton = view.findViewById<Switch>(R.id.switchPowerButton)
        val switchLongPress = view.findViewById<Switch>(R.id.switchLongPress)
        val switchShake = view.findViewById<Switch>(R.id.switchShake)
        val modeRadioGroup = view.findViewById<RadioGroup>(R.id.modeRadioGroup)
        val switchSiren = view.findViewById<Switch>(R.id.switchSiren)
        val switchFlash = view.findViewById<Switch>(R.id.switchFlash)
        val trackingIntervalInput = view.findViewById<EditText>(R.id.trackingIntervalInput)
        val switchEmergencyCalling = view.findViewById<Switch>(R.id.switchEmergencyCalling)
        val callDelayInput = view.findViewById<EditText>(R.id.callDelayInput)

        // Mevcut ayarları forma yükle
        fullNameInput.setText(settings.fullName)
        customMessageInput.setText(settings.customMessage)
        switchPowerButton.isChecked = settings.triggerPowerButton
        switchLongPress.isChecked = settings.triggerLongPressSos
        switchShake.isChecked = settings.triggerShake
        if (settings.loudMode) view.findViewById<android.widget.RadioButton>(R.id.radioLoud).isChecked = true
        else view.findViewById<android.widget.RadioButton>(R.id.radioSilent).isChecked = true
        switchSiren.isChecked = settings.playSiren
        switchFlash.isChecked = settings.flashTorch
        trackingIntervalInput.setText(settings.trackingIntervalSeconds.toString())
        switchEmergencyCalling.isChecked = settings.emergencyCallingEnabled
        callDelayInput.setText(settings.callDelaySeconds.toString())

        fun saveAll() {
            val current = SettingsHelper.getSettings(requireContext())
            val updated = current.copy(
                fullName = fullNameInput.text.toString(),
                customMessage = customMessageInput.text.toString(),
                triggerPowerButton = switchPowerButton.isChecked,
                triggerLongPressSos = switchLongPress.isChecked,
                triggerShake = switchShake.isChecked,
                loudMode = view.findViewById<android.widget.RadioButton>(R.id.radioLoud).isChecked,
                playSiren = switchSiren.isChecked,
                flashTorch = switchFlash.isChecked,
                trackingIntervalSeconds = trackingIntervalInput.text.toString().toIntOrNull() ?: 60,
                emergencyCallingEnabled = switchEmergencyCalling.isChecked,
                callDelaySeconds = callDelayInput.text.toString().toIntOrNull() ?: 10
            )
            SettingsHelper.saveSettings(requireContext(), updated)
        }

        // Her değişiklikte otomatik kaydet
        val switches = listOf(switchPowerButton, switchLongPress, switchShake, switchSiren, switchFlash, switchEmergencyCalling)
        switches.forEach { it.setOnCheckedChangeListener { _, _ -> saveAll() } }
        modeRadioGroup.setOnCheckedChangeListener { _, _ -> saveAll() }

        val editTexts = listOf(fullNameInput, customMessageInput, trackingIntervalInput, callDelayInput)
        editTexts.forEach { editText ->
            editText.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) saveAll() }
        }

        // Kişi listesi
        val contactsRecyclerView = view.findViewById<RecyclerView>(R.id.contactsRecyclerView)
        val contactNameInput = view.findViewById<EditText>(R.id.contactNameInput)
        val contactPhoneInput = view.findViewById<EditText>(R.id.contactPhoneInput)
        val addContactButton = view.findViewById<Button>(R.id.addContactButton)

        val contacts = PrefsHelper.getContacts(requireContext())
        contactsAdapter = ContactsAdapter(contacts) { contactToDelete ->
            PrefsHelper.removeContact(requireContext(), contactToDelete)
            contactsAdapter.updateData(PrefsHelper.getContacts(requireContext()))
        }
        contactsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        contactsRecyclerView.adapter = contactsAdapter

        addContactButton.setOnClickListener {
            val name = contactNameInput.text.toString().trim()
            val phone = contactPhoneInput.text.toString().trim()
            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(requireContext(), "İsim ve telefon numarası girin", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            PrefsHelper.addContact(requireContext(), Contact(name, phone))
            contactsAdapter.updateData(PrefsHelper.getContacts(requireContext()))
            contactNameInput.text.clear()
            contactPhoneInput.text.clear()
        }

        // Hakkında satırı -> Bilgi sekmesine geç
        view.findViewById<View>(R.id.aboutRow).setOnClickListener {
            (activity as? MainActivity)?.switchToTab(R.id.nav_info)
        }
    }

    override fun onPause() {
        super.onPause()
        // Fragment kapanırken son değerleri de kaydet (focus kaybı yakalanmamış olabilir)
        view?.let { v ->
            val fullNameInput = v.findViewById<EditText>(R.id.fullNameInput)
            val customMessageInput = v.findViewById<EditText>(R.id.customMessageInput)
            val trackingIntervalInput = v.findViewById<EditText>(R.id.trackingIntervalInput)
            val callDelayInput = v.findViewById<EditText>(R.id.callDelayInput)
            val switchPowerButton = v.findViewById<Switch>(R.id.switchPowerButton)
            val switchLongPress = v.findViewById<Switch>(R.id.switchLongPress)
            val switchShake = v.findViewById<Switch>(R.id.switchShake)
            val switchSiren = v.findViewById<Switch>(R.id.switchSiren)
            val switchFlash = v.findViewById<Switch>(R.id.switchFlash)
            val switchEmergencyCalling = v.findViewById<Switch>(R.id.switchEmergencyCalling)
            val loud = v.findViewById<android.widget.RadioButton>(R.id.radioLoud).isChecked

            val current = SettingsHelper.getSettings(requireContext())
            val updated = current.copy(
                fullName = fullNameInput.text.toString(),
                customMessage = customMessageInput.text.toString(),
                triggerPowerButton = switchPowerButton.isChecked,
                triggerLongPressSos = switchLongPress.isChecked,
                triggerShake = switchShake.isChecked,
                loudMode = loud,
                playSiren = switchSiren.isChecked,
                flashTorch = switchFlash.isChecked,
                trackingIntervalSeconds = trackingIntervalInput.text.toString().toIntOrNull() ?: 60,
                emergencyCallingEnabled = switchEmergencyCalling.isChecked,
                callDelaySeconds = callDelayInput.text.toString().toIntOrNull() ?: 10
            )
            SettingsHelper.saveSettings(requireContext(), updated)
        }
    }
}
