package com.example.sosapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HistoryEvent(
    val timestampMillis: Long,
    val description: String
) {
    fun formattedDate(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("tr"))
        return sdf.format(Date(timestampMillis))
    }
}

object HistoryHelper {

    private const val PREFS_NAME = "sos_history"
    private const val KEY_EVENTS = "events"

    fun getEvents(context: Context): List<HistoryEvent> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_EVENTS, null) ?: return emptyList()

        val list = mutableListOf<HistoryEvent>()
        val array = JSONArray(json)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(HistoryEvent(obj.getLong("timestamp"), obj.getString("description")))
        }
        return list.sortedByDescending { it.timestampMillis }
    }

    fun addEvent(context: Context, description: String) {
        val events = getEvents(context).toMutableList()
        events.add(0, HistoryEvent(System.currentTimeMillis(), description))

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray()
        for (event in events) {
            val obj = JSONObject()
            obj.put("timestamp", event.timestampMillis)
            obj.put("description", event.description)
            array.put(obj)
        }
        prefs.edit().putString(KEY_EVENTS, array.toString()).apply()
    }

    fun getLastEvent(context: Context): HistoryEvent? {
        return getEvents(context).firstOrNull()
    }
}
