package com.example.sosapp

import android.content.Context

object SettingsHelper {

    private const val PREFS_NAME = "sos_settings"

    fun getSettings(context: Context): AppSettings {
        val p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return AppSettings(
            fullName = p.getString("fullName", "") ?: "",
            customMessage = p.getString("customMessage", "") ?: "",
            triggerPowerButton = p.getBoolean("triggerPowerButton", true),
            triggerLongPressSos = p.getBoolean("triggerLongPressSos", false),
            triggerVolumeButtons = p.getBoolean("triggerVolumeButtons", false),
            triggerShake = p.getBoolean("triggerShake", false),
            triggerVoice = p.getBoolean("triggerVoice", false),
            loudMode = p.getBoolean("loudMode", true),
            playSiren = p.getBoolean("playSiren", true),
            flashTorch = p.getBoolean("flashTorch", true),
            trackingIntervalSeconds = p.getInt("trackingIntervalSeconds", 60),
            emergencyCallingEnabled = p.getBoolean("emergencyCallingEnabled", false),
            callDelaySeconds = p.getInt("callDelaySeconds", 10),
            primaryCallContactPhone = p.getString("primaryCallContactPhone", "") ?: ""
        )
    }

    fun saveSettings(context: Context, settings: AppSettings) {
        val p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        p.edit()
            .putString("fullName", settings.fullName)
            .putString("customMessage", settings.customMessage)
            .putBoolean("triggerPowerButton", settings.triggerPowerButton)
            .putBoolean("triggerLongPressSos", settings.triggerLongPressSos)
            .putBoolean("triggerVolumeButtons", settings.triggerVolumeButtons)
            .putBoolean("triggerShake", settings.triggerShake)
            .putBoolean("triggerVoice", settings.triggerVoice)
            .putBoolean("loudMode", settings.loudMode)
            .putBoolean("playSiren", settings.playSiren)
            .putBoolean("flashTorch", settings.flashTorch)
            .putInt("trackingIntervalSeconds", settings.trackingIntervalSeconds)
            .putBoolean("emergencyCallingEnabled", settings.emergencyCallingEnabled)
            .putInt("callDelaySeconds", settings.callDelaySeconds)
            .putString("primaryCallContactPhone", settings.primaryCallContactPhone)
            .apply()
    }
}
