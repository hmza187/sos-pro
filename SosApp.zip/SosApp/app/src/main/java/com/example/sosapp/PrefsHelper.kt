package com.example.sosapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Kişileri basit bir şekilde SharedPreferences içinde JSON olarak saklar.
 * Daha büyük bir uygulamada bunun yerine Room veritabanı kullanılabilir.
 */
object PrefsHelper {

    private const val PREFS_NAME = "sos_prefs"
    private const val KEY_CONTACTS = "contacts"

    fun getContacts(context: Context): MutableList<Contact> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_CONTACTS, null) ?: return mutableListOf()

        val list = mutableListOf<Contact>()
        val array = JSONArray(json)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(Contact(obj.getString("name"), obj.getString("phone"), obj.optInt("priority", 1)))
        }
        return list
    }

    fun saveContacts(context: Context, contacts: List<Contact>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray()
        for (contact in contacts) {
            val obj = JSONObject()
            obj.put("name", contact.name)
            obj.put("phone", contact.phone)
            obj.put("priority", contact.priority)
            array.put(obj)
        }
        prefs.edit().putString(KEY_CONTACTS, array.toString()).apply()
    }

    fun addContact(context: Context, contact: Contact) {
        val contacts = getContacts(context)
        contacts.add(contact)
        saveContacts(context, contacts)
    }

    fun removeContact(context: Context, contact: Contact) {
        val contacts = getContacts(context)
        contacts.removeAll { it.phone == contact.phone && it.name == contact.name }
        saveContacts(context, contacts)
    }
}
