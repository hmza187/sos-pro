package com.example.sosapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class SosFragment : Fragment() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_sos, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())

        val sosButton = view.findViewById<Button>(R.id.sosButton)
        val editContactButton = view.findViewById<Button>(R.id.editContactButton)
        val quickAddContact = view.findViewById<Button>(R.id.quickAddContact)
        val quickHistory = view.findViewById<Button>(R.id.quickHistory)
        val quickSettings = view.findViewById<Button>(R.id.quickSettings)

        sosButton.setOnClickListener { triggerSos() }
        editContactButton.setOnClickListener { (activity as? MainActivity)?.switchToTab(R.id.nav_settings) }
        quickAddContact.setOnClickListener { (activity as? MainActivity)?.switchToTab(R.id.nav_settings) }
        quickHistory.setOnClickListener { (activity as? MainActivity)?.switchToTab(R.id.nav_timeline) }
        quickSettings.setOnClickListener { (activity as? MainActivity)?.switchToTab(R.id.nav_settings) }

        updateUi(view)
    }

    override fun onResume() {
        super.onResume()
        view?.let { updateUi(it) }
    }

    private fun updateUi(view: View) {
        val contacts = PrefsHelper.getContacts(requireContext())
        val primaryName = view.findViewById<TextView>(R.id.primaryContactName)
        val primaryPhone = view.findViewById<TextView>(R.id.primaryContactPhone)

        if (contacts.isNotEmpty()) {
            val primary = contacts.minByOrNull { it.priority } ?: contacts.first()
            primaryName.text = "Kişi: ${primary.name}"
            primaryPhone.text = "Telefon: ${primary.phone}"
        } else {
            primaryName.text = "Kişi: — (henüz eklenmedi)"
            primaryPhone.text = "Telefon: —"
        }

        val gpsStatus = view.findViewById<TextView>(R.id.gpsStatusText)
        val hasLocationPermission = ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        gpsStatus.text = if (hasLocationPermission) {
            "📍 GPS Durumu: Aktif"
        } else {
            "📍 GPS Durumu: İzin verilmedi"
        }

        val lastSosText = view.findViewById<TextView>(R.id.lastSosText)
        val lastEvent = HistoryHelper.getLastEvent(requireContext())
        lastSosText.text = if (lastEvent != null) {
            "🕐 Son SOS: ${lastEvent.formattedDate()}"
        } else {
            "🕐 Son SOS: Hiç tetiklenmedi"
        }
    }

    private fun triggerSos() {
        val contacts = PrefsHelper.getContacts(requireContext())
        if (contacts.isEmpty()) {
            Toast.makeText(requireContext(), getString(R.string.no_contacts), Toast.LENGTH_LONG).show()
            return
        }

        val hasSmsPermission = ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
        val hasLocationPermission = ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasSmsPermission || !hasLocationPermission) {
            Toast.makeText(requireContext(), getString(R.string.permission_needed), Toast.LENGTH_LONG).show()
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            val locationText = if (location != null) {
                "https://maps.google.com/?q=${location.latitude},${location.longitude}"
            } else {
                "konum alınamadı"
            }

            val settings = SettingsHelper.getSettings(requireContext())
            val baseMessage = if (settings.customMessage.isNotBlank()) {
                settings.customMessage
            } else {
                getString(R.string.sos_message, locationText)
            }
            val fullMessage = if (settings.customMessage.isNotBlank()) {
                "$baseMessage Konum: $locationText"
            } else {
                baseMessage
            }

            sendSmsToContacts(contacts, fullMessage)

            HistoryHelper.addEvent(requireContext(), "SOS Tetiklendi — ${contacts.size} kişiye gönderildi")
            Toast.makeText(requireContext(), getString(R.string.sms_sent), Toast.LENGTH_LONG).show()
            view?.let { updateUi(it) }
        }.addOnFailureListener {
            Toast.makeText(requireContext(), "Konum alınamadı, mesaj konumsuz gönderilecek", Toast.LENGTH_SHORT).show()
            val settings = SettingsHelper.getSettings(requireContext())
            val message = settings.customMessage.ifBlank {
                getString(R.string.sos_message, "konum alınamadı")
            }
            sendSmsToContacts(contacts, message)
            HistoryHelper.addEvent(requireContext(), "SOS Tetiklendi (konumsuz) — ${contacts.size} kişiye gönderildi")
            view?.let { updateUi(it) }
        }
    }

    private fun sendSmsToContacts(contacts: List<Contact>, message: String) {
        val smsManager = SmsManager.getDefault()
        for (contact in contacts) {
            try {
                val parts = smsManager.divideMessage(message)
                smsManager.sendMultipartTextMessage(contact.phone, null, parts, null, null)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "${contact.name} numarasına gönderilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
