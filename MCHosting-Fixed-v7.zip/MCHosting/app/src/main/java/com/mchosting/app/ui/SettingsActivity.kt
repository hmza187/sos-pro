
package com.mchosting.app.ui
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mchosting.app.R
import com.mchosting.app.utils.Prefs
class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val prefs = Prefs(this)
        val etName = findViewById<EditText>(R.id.etServerName)
        val etSeed = findViewById<EditText>(R.id.etSeed)
        val btnSave = findViewById<Button>(R.id.btnSave)
        etName.setText(prefs.getServerName())
        etSeed.setText(prefs.getSeed())
        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val seed = etSeed.text.toString().trim()
            if (!prefs.isServerNameValid(name)) { Toast.makeText(this, "Sunucu adı en az 6 karakter + 1 rakam içermeli!", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            if (!prefs.isSeedValid(seed)) { Toast.makeText(this, "Seed sadece rakamlardan oluşmalı!", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            prefs.setServerName(name); prefs.setSeed(seed)
            Toast.makeText(this, "Kaydedildi!", Toast.LENGTH_SHORT).show(); finish()
        }
    }
}
