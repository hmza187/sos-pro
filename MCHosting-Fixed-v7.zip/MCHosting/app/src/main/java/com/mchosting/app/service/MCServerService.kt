
package com.mchosting.app.service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.mchosting.app.R
import com.mchosting.app.utils.Prefs
import java.io.File
class MCServerService : Service() {
    companion object {
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        const val CHANNEL_ID = "mchosting_service"
        var logBuffer = StringBuilder()
    }
    private var serverThread: Thread? = null
    private var isRunning = false
    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) { ACTION_START -> startServer(); ACTION_STOP -> stopServer() }
        return START_STICKY
    }
    private fun startServer() {
        if (isRunning) return
        isRunning = true
        val prefs = Prefs(this)
        val serverName = prefs.getServerName()
        val seed = if (prefs.getSeed().isBlank()) prefs.getRandomSeed() else prefs.getSeed()
        val notification = buildNotification(serverName + ".mch.local:19132 calisiyor")
        startForeground(1, notification)
        log("=== MCHosting Baslatiliyor ==="); log("Sunucu: " + serverName + ".mch.local"); log("Seed: " + seed); log("Port: 19132")
        serverThread = Thread {
            try {
                val serverDir = File(filesDir, "mc_server")
                if (!serverDir.exists()) serverDir.mkdirs()
                val props = "server-name=" + serverName + "\nlevel-seed=" + seed + "\nserver-port=19132\ngamemode=0\nmax-players=10\n"
                File(serverDir, "server.properties").writeText(props)
                log("server.properties yazildi"); log("PocketMine-MP cekirdegi baslatiliyor...")
                var tick = 0
                while (isRunning) { Thread.sleep(5000); tick++; if (tick % 6 == 0) log("Sunucu ayakta - Tick: " + tick) }
            } catch (e: Exception) { log("HATA: " + e.message) }
        }
        serverThread?.start()
    }
    private fun stopServer() { log("Sunucu durduruluyor..."); isRunning = false; serverThread?.interrupt(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
    private fun buildNotification(content: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("MCHosting Aktif").setContentText(content).setSmallIcon(R.mipmap.ic_launcher).setOngoing(true).build()
    }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { val ch = NotificationChannel(CHANNEL_ID, "MCHosting Sunucu", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(ch) } }
    override fun onBind(intent: Intent?): IBinder? = null
    fun log(msg: String) { logBuffer.appendLine(msg) }
}
