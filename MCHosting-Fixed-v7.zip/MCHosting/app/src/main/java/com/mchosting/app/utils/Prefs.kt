
package com.mchosting.app.utils
import android.content.Context
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("mchosting", Context.MODE_PRIVATE)
    fun getServerName(): String = sp.getString("server_name", "gaziantep27") ?: "gaziantep27"
    fun setServerName(v: String) = sp.edit().putString("server_name", v).apply()
    fun getSeed(): String = sp.getString("seed", "") ?: ""
    fun setSeed(v: String) = sp.edit().putString("seed", v).apply()
    fun isServerNameValid(name: String): Boolean { if (name.length < 6) return false; return name.any { it.isDigit() } }
    fun isSeedValid(seed: String): Boolean { if (seed.isBlank()) return true; return seed.all { it.isDigit() } }
    fun getRandomSeed(): String = (100000000000000000L..999999999999999999L).random().toString()
}
