
package com.mchosting.app.ui
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.mchosting.app.R
import com.mchosting.app.service.MCServerService
class ConsoleActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val runnable = object : Runnable {
        override fun run() { findViewById<TextView>(R.id.tvConsole).text = MCServerService.logBuffer.toString(); handler.postDelayed(this, 1000) }
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_console); handler.post(runnable) }
    override fun onDestroy() { handler.removeCallbacks(runnable); super.onDestroy() }
}
