
package com.mchosting.app
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import android.widget.TextView
import com.mchosting.app.service.MCServerService
import com.mchosting.app.ui.ConsoleActivity
import com.mchosting.app.ui.SettingsActivity
import com.mchosting.app.utils.Prefs
class MainActivity : AppCompatActivity() {
    private var isRunning = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnStartStop = findViewById<MaterialButton>(R.id.btnStartStop)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val btnSettings = findViewById<MaterialButton>(R.id.btnSettings)
        val btnConsole = findViewById<MaterialButton>(R.id.btnConsole)
        val prefs = Prefs(this)
        updateUI(prefs.getServerName(), false, tvStatus, btnStartStop)
        btnStartStop.setOnClickListener {
            if (!isRunning) {
                val name = prefs.getServerName()
                if (!prefs.isServerNameValid(name)) { tvStatus.text = "Hata: Sunucu adı en az 6 karakter + 1 rakam olmalı!"; return@setOnClickListener }
                if (!prefs.isSeedValid(prefs.getSeed())) { tvStatus.text = "Hata: Seed sadece rakamlardan olmalı!"; return@setOnClickListener }
                val intent = Intent(this, MCServerService::class.java).apply { action = MCServerService.ACTION_START }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
                updateUI(name, true, tvStatus, btnStartStop)
            } else {
                val intent = Intent(this, MCServerService::class.java).apply { action = MCServerService.ACTION_STOP }
                startService(intent)
                updateUI(prefs.getServerName(), false, tvStatus, btnStartStop)
            }
        }
        btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        btnConsole.setOnClickListener { startActivity(Intent(this, ConsoleActivity::class.java)) }
    }
    private fun updateUI(serverName: String, running: Boolean, tv: TextView, btn: MaterialButton) {
        isRunning = running
        if (running) { tv.text = getString(R.string.status_running, serverName + ".mch.local"); btn.text = getString(R.string.stop_server) }
        else { tv.text = getString(R.string.status_stopped); btn.text = getString(R.string.start_server) }
    }
}
