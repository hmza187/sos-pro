# MCHosting - Telefonu Minecraft Sunucusuna Çevir

Boilerplate hazır! DeepSeek spec ile uyumlu.
